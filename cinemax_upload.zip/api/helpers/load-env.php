<?php
/**
 * Load environment variables from .env file
 * Call this at the top of config/db.php to support .env configuration
 */

$envFile = __DIR__ . '/../.env';

if (file_exists($envFile)) {
    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    
    foreach ($lines as $line) {
        // Skip comments
        if (strpos(trim($line), '#') === 0) {
            continue;
        }
        
        // Parse line
        if (strpos($line, '=') === false) {
            continue;
        }
        
        list($key, $value) = explode('=', $line, 2);
        $key = trim($key);
        $value = trim($value, '\'" ');
        
        // Set environment variable
        if (!empty($key) && !getenv($key)) {
            putenv("$key=$value");
        }
    }
}
