<?php
/**
 * CineMax API - Main Router
 */

// Headers
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Timezone: UTC+7 (Vietnam / Hanoi / Ho Chi Minh)
date_default_timezone_set('Asia/Ho_Chi_Minh');

// Database connection
$conn = require_once __DIR__ . '/config/db.php';

// Set MySQL session timezone to UTC+7
$conn->query("SET time_zone = '+07:00'");

// Get request method and path
$method = $_SERVER['REQUEST_METHOD'];

// Support both /api/movies and /api/api.php?request=movies
$route = '';
if (isset($_GET['request'])) {
    $route = trim($_GET['request']);
} else {
    $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    $path = str_replace('/api/', '', $path);
    $path = str_replace('api.php', '', $path);
    $parts = array_filter(explode('/', $path));
    $route = trim(implode('/', $parts));
}

// Debug: Log route
error_log("Route: '$route', Method: '$method'");

// Helper functions
function respond($data, $statusCode = 200) {
    http_response_code($statusCode);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function get_json_body() {
    return json_decode(file_get_contents('php://input'), true);
}

function generate_code($prefix = 'CNM') {
    return $prefix . strtoupper(substr(md5(microtime()), 0, 8));
}

// ============================================
// HEALTH CHECK
// ============================================
if ($route === 'health') {
    $dbStatus = 'OK';
    $dbMsg = '';
    
    // Test database connection
    $testResult = $conn->query("SELECT 1");
    if (!$testResult) {
        $dbStatus = 'ERROR';
        $dbMsg = $conn->error;
    }
    
    respond([
        'ok' => true, 
        'route' => $route, 
        'method' => $method,
        'database' => $dbStatus,
        'dbError' => $dbMsg
    ]);
}

// ============================================
// ADMIN: UPDATE SHOWTIMES
// ============================================
if ($route === 'admin/update-showtimes' && $method === 'POST') {
    // Security: simple token check (you should enhance this)
    $token = isset($_GET['token']) ? $_GET['token'] : (isset($_POST['token']) ? $_POST['token'] : '');
    if ($token !== 'ADMIN_CINEMAX_2026') {
        respond(['error' => 'Unauthorized'], 401);
    }
    
    try {
        // Delete old showtimes
        $conn->query("DELETE FROM showtimes");
        echo "✓ Deleted old showtimes\n";
        
        // Read the SQL file with INSERT statements
        $sqlFile = __DIR__ . '/../showtimes-current.sql';
        if (!file_exists($sqlFile)) {
            respond(['error' => 'File not found: ' . $sqlFile], 404);
        }
        
        $sql = file_get_contents($sqlFile);
        
        // Execute multiple statements
        $statements = array_filter(array_map('trim', preg_split('/;(?=([^\']*\'[^\']*\')*[^\']*$)/', $sql)));
        
        $executedCount = 0;
        $errorCount = 0;
        $errors = [];
        
        foreach ($statements as $statement) {
            if (empty($statement) || substr(trim($statement), 0, 2) === '--') {
                continue; // Skip empty and comment lines
            }
            
            if ($conn->query($statement)) {
                $executedCount++;
            } else {
                $errorCount++;
                $errors[] = $conn->error;
            }
        }
        
        // Verify data
        $result = $conn->query("SELECT COUNT(*) as total FROM showtimes");
        $stats = $result->fetch_assoc();
        
        respond([
            'success' => true,
            'message' => 'Showtimes updated successfully',
            'executed' => $executedCount,
            'errors' => $errorCount,
            'errorDetails' => $errors,
            'totalShowtimes' => $stats['total']
        ]);
        
    } catch (Exception $e) {
        respond(['error' => $e->getMessage()], 500);
    }
}

// ============================================
// MOVIES API
// ============================================
if ($route === 'movies' && $method === 'GET') {
    $status = isset($_GET['status']) ? $conn->real_escape_string($_GET['status']) : '';
    $query = 'SELECT * FROM movies';
    if ($status) {
        $query .= " WHERE Status = '$status'";
    }
    $query .= ' ORDER BY CreatedAt DESC';
    
    $result = $conn->query($query);
    if (!$result) {
        respond(['error' => 'Movies query failed: ' . $conn->error], 500);
    }
    
    $movies = [];
    while ($row = $result->fetch_assoc()) {
        $movies[] = $row;
    }
    respond($movies);
}

if (preg_match('/^movies\/(\d+)$/', $route, $matches) && $method === 'GET') {
    $movieId = $matches[1];
    $result = $conn->query("SELECT * FROM movies WHERE MovieID = $movieId");
    
    if (!$result) {
        respond(['error' => 'Query failed: ' . $conn->error], 500);
    }
    
    if ($result->num_rows === 0) {
        respond(['error' => 'Phim không tồn tại'], 404);
    }
    
    $movie = $result->fetch_assoc();
    respond($movie);
}

if ($route === 'admin/movies' && $method === 'POST') {
    $data = get_json_body();
    $stmt = $conn->prepare("
        INSERT INTO movies (Title, Description, Duration, AgeLimit, PosterUrl, TrailerUrl, Status)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    
    $status = $data['status'] ?? 'COMING_SOON';
    $stmt->bind_param('ssiiiss', $data['title'], $data['description'], $data['duration'], $data['ageLimit'], $data['posterUrl'], $data['trailerUrl'], $status);
    
    if ($stmt->execute()) {
        $movieId = $conn->insert_id;
        $result = $conn->query("SELECT * FROM movies WHERE MovieID = $movieId");
        if (!$result) {
            respond(['error' => 'Query failed: ' . $conn->error], 500);
        }
        $movie = $result->fetch_assoc();
        respond($movie, 201);
    } else {
        respond(['error' => 'Lỗi tạo phim: ' . $stmt->error], 500);
    }
}

// ============================================
// CINEMAS API
// ============================================
if ($route === 'cinemas' && $method === 'GET') {
    $result = $conn->query("
        SELECT c.CinemaID, c.Name, c.Address, c.Status, COUNT(r.RoomID) AS RoomCount
        FROM cinemas c
        LEFT JOIN rooms r ON r.CinemaID = c.CinemaID
        GROUP BY c.CinemaID
        ORDER BY c.Name
    ");
    
    if (!$result) {
        respond(['error' => 'Cinemas query failed: ' . $conn->error], 500);
    }
    
    $cinemas = [];
    while ($row = $result->fetch_assoc()) {
        $cinemas[] = $row;
    }
    respond($cinemas);
}

if (preg_match('/^cinemas\/(\d+)\/rooms$/', $route, $matches) && $method === 'GET') {
    $cinemaId = $matches[1];
    $result = $conn->query("SELECT * FROM rooms WHERE CinemaID = $cinemaId ORDER BY RoomName");
    
    if (!$result) {
        respond(['error' => 'Query failed: ' . $conn->error], 500);
    }
    
    $rooms = [];
    while ($row = $result->fetch_assoc()) {
        $rooms[] = $row;
    }
    respond($rooms);
}

// ============================================
// SHOWTIMES API
// ============================================

// GET single showtime by ID
if (preg_match('/^showtimes\/(\d+)$/', $route, $matches) && $method === 'GET') {
    $showtimeId = (int)$matches[1];

    $result = $conn->query("
        SELECT 
            s.ShowtimeID, s.MovieID,
            DATE_FORMAT(s.ShowDate, '%Y-%m-%d') AS ShowDate,
            DATE_FORMAT(s.ShowTime, '%H:%i') AS ShowTime,
            s.Price,
            m.Title AS MovieTitle, m.Duration, m.PosterUrl,
            c.CinemaID, c.Name AS CinemaName, c.Address AS CinemaAddress, c.Status AS CinemaStatus,
            r.RoomID, r.RoomName, r.TotalSeats
        FROM showtimes s
        JOIN movies m ON s.MovieID = m.MovieID
        JOIN rooms r ON s.RoomID = r.RoomID
        JOIN cinemas c ON r.CinemaID = c.CinemaID
        WHERE s.ShowtimeID = $showtimeId
        LIMIT 1
    ");

    if (!$result) {
        respond(['error' => 'Query failed: ' . $conn->error], 500);
    }
    if ($result->num_rows === 0) {
        respond(['error' => 'Suất chiếu không tồn tại'], 404);
    }

    $showtime = $result->fetch_assoc();
    respond($showtime);
}

if (preg_match('/^showtimes\/(\d+)\/seats$/', $route, $matches) && $method === 'GET') {
    $showtimeId = (int)$matches[1];

    $showtimeResult = $conn->query("
        SELECT 
            s.ShowtimeID, s.MovieID,
            DATE_FORMAT(s.ShowDate, '%Y-%m-%d') AS ShowDate,
            DATE_FORMAT(s.ShowTime, '%H:%i') AS ShowTime,
            s.Price,
            m.Title AS MovieTitle,
            c.CinemaID, c.Name AS CinemaName,
            r.RoomID, r.RoomName, r.TotalSeats
        FROM showtimes s
        JOIN movies m ON s.MovieID = m.MovieID
        JOIN rooms r ON s.RoomID = r.RoomID
        JOIN cinemas c ON r.CinemaID = c.CinemaID
        WHERE s.ShowtimeID = $showtimeId
        LIMIT 1
    ");

    if (!$showtimeResult) {
        respond(['error' => 'Query failed: ' . $conn->error], 500);
    }
    if ($showtimeResult->num_rows === 0) {
        respond(['error' => 'Suất chiếu không tồn tại'], 404);
    }

    $showtime = $showtimeResult->fetch_assoc();

    $bookedSeats = [];
    $booked = $conn->query("
        SELECT SeatNumbers
        FROM bookings
        WHERE ShowtimeID = $showtimeId
          AND Status = 'CONFIRMED'
    ");

    if ($booked) {
        while ($row = $booked->fetch_assoc()) {
            $seatNumbers = (string)($row['SeatNumbers'] ?? '');
            if ($seatNumbers === '') {
                continue;
            }
            $parts = array_map('trim', explode(',', $seatNumbers));
            foreach ($parts as $seat) {
                if ($seat === '') continue;
                $bookedSeats[] = $seat;
            }
        }
    }

    $bookedSeats = array_values(array_unique($bookedSeats));
    sort($bookedSeats);

    $totalSeats = (int)($showtime['TotalSeats'] ?? 0);
    $emptySeats = $totalSeats > 0 ? max($totalSeats - count($bookedSeats), 0) : null;

    respond([
        'showtime' => $showtime,
        'bookedSeats' => $bookedSeats,
        'bookedCount' => count($bookedSeats),
        'emptyCount' => $emptySeats,
        'totalSeats' => $totalSeats,
    ]);
}

if ($route === 'showtimes' && $method === 'GET') {
    $movieId = isset($_GET['movieId']) ? (int)$_GET['movieId'] : null;
    $date = isset($_GET['date']) ? $conn->real_escape_string($_GET['date']) : null;
    
    $query = "
        SELECT 
            s.ShowtimeID, s.MovieID,
            DATE_FORMAT(s.ShowDate, '%Y-%m-%d') AS ShowDate,
            DATE_FORMAT(s.ShowTime, '%H:%i') AS ShowTime,
            s.Price,
            m.Title, m.Duration, m.PosterUrl,
            c.CinemaID, c.Name AS CinemaName, c.Address AS CinemaAddress,
            r.RoomID, r.RoomName, r.TotalSeats
        FROM showtimes s
        JOIN movies m ON s.MovieID = m.MovieID
        JOIN rooms r ON s.RoomID = r.RoomID
        JOIN cinemas c ON r.CinemaID = c.CinemaID
        WHERE 1=1
    ";
    
    if ($movieId) {
        $query .= " AND s.MovieID = $movieId";
    }
    if ($date) {
        $query .= " AND DATE(s.ShowDate) = '$date'";
    }
    $query .= " ORDER BY s.ShowDate, s.ShowTime";
    
    $result = $conn->query($query);
    if (!$result) {
        respond(['error' => 'Showtimes query failed: ' . $conn->error], 500);
    }
    
    $showtimes = [];
    while ($row = $result->fetch_assoc()) {
        $showtimes[] = $row;
    }
    respond($showtimes);
}

// ============================================
// BOOKINGS API
// ============================================
if ($route === 'bookings' && $method === 'GET') {
    $result = $conn->query("
        SELECT 
            b.BookingID, 
            b.UserID,
            b.ShowtimeID, 
            b.SeatNumbers, 
            b.TotalSeats,
            b.TotalPrice, 
            b.Status,
            b.BookingCode,
            b.CreatedAt,
            u.FullName AS UserName,
            u.Email AS UserEmail,
            u.Phone AS PhoneNumber,
            m.Title AS MovieTitle,
            m.Duration,
            m.AgeLimit,
            s.ShowDate,
            s.ShowTime,
            s.Price AS ShowPrice,
            r.RoomName,
            c.Name AS CinemaName,
            c.Address AS CinemaAddress
        FROM bookings b
        LEFT JOIN users u ON b.UserID = u.UserID
        LEFT JOIN showtimes s ON b.ShowtimeID = s.ShowtimeID
        LEFT JOIN movies m ON s.MovieID = m.MovieID
        LEFT JOIN rooms r ON s.RoomID = r.RoomID
        LEFT JOIN cinemas c ON r.CinemaID = c.CinemaID
        ORDER BY b.CreatedAt DESC
    ");
    
    if (!$result) {
        respond(['error' => 'Bookings query failed: ' . $conn->error], 500);
    }
    
    $bookings = [];
    while ($row = $result->fetch_assoc()) {
        $bookings[] = $row;
    }
    respond($bookings);
}

if ($route === 'bookings' && $method === 'POST') {
    $data = get_json_body();
    $bookingCode = generate_code();
    
    $stmt = $conn->prepare("
        INSERT INTO bookings (UserID, ShowtimeID, SeatNumbers, TotalSeats, TotalPrice, Status, BookingCode)
        VALUES (?, ?, ?, ?, ?, 'CONFIRMED', ?)
    ");
    
    $stmt->bind_param('iisiss', $data['userId'], $data['showtimeId'], $data['seatNumbers'], $data['totalSeats'], $data['totalPrice'], $bookingCode);
    
    if ($stmt->execute()) {
        $bookingId = $conn->insert_id;
        
        // Create tickets
        $seats = array_map('trim', explode(',', $data['seatNumbers']));
        foreach ($seats as $idx => $seat) {
            $ticketCode = $bookingCode . '-' . ($idx + 1);
            $conn->query("INSERT INTO tickets (BookingID, TicketCode, SeatNumber, Status) VALUES ($bookingId, '$ticketCode', '$seat', 'ACTIVE')");
        }
        
        // Return full booking details with related data
        $result = $conn->query("
            SELECT 
                b.BookingID, 
                b.UserID,
                b.ShowtimeID, 
                b.SeatNumbers, 
                b.TotalSeats,
                b.TotalPrice, 
                b.Status,
                b.BookingCode,
                b.CreatedAt,
                u.FullName AS UserName,
                u.Email AS UserEmail,
                u.Phone AS PhoneNumber,
                m.Title AS MovieTitle,
                m.Duration,
                m.AgeLimit,
                s.ShowDate,
                s.ShowTime,
                s.Price AS ShowPrice,
                r.RoomName,
                c.Name AS CinemaName,
                c.Address AS CinemaAddress
            FROM bookings b
            LEFT JOIN users u ON b.UserID = u.UserID
            LEFT JOIN showtimes s ON b.ShowtimeID = s.ShowtimeID
            LEFT JOIN movies m ON s.MovieID = m.MovieID
            LEFT JOIN rooms r ON s.RoomID = r.RoomID
            LEFT JOIN cinemas c ON r.CinemaID = c.CinemaID
            WHERE b.BookingID = $bookingId
        ");
        
        if ($result) {
            $booking = $result->fetch_assoc();
            respond($booking, 201);
        }
    } else {
        respond(['error' => 'Lỗi tạo booking: ' . $stmt->error], 500);
    }
}

// Get user bookings with movie details
if (preg_match('/^bookings\/user\/(\d+)$/', $route, $matches) && $method === 'GET') {
    $userId = (int)$matches[1];
    
    $result = $conn->query("
        SELECT 
            b.BookingID, b.UserID, b.ShowtimeID, 
            b.SeatNumbers, b.TotalSeats, b.TotalPrice, 
            b.Status, b.BookingCode, b.CreatedAt,
            m.MovieID, m.Title AS MovieTitle, m.PosterUrl, m.Duration,
            s.ShowDate, s.ShowTime, s.Price,
            c.CinemaID, c.Name AS CinemaName,
            r.RoomName
        FROM bookings b
        JOIN showtimes s ON b.ShowtimeID = s.ShowtimeID
        JOIN movies m ON s.MovieID = m.MovieID
        JOIN rooms r ON s.RoomID = r.RoomID
        JOIN cinemas c ON r.CinemaID = c.CinemaID
        WHERE b.UserID = $userId
        ORDER BY b.CreatedAt DESC
    ");
    
    if (!$result) {
        respond(['error' => 'Query failed: ' . $conn->error], 500);
    }
    
    $bookings = [];
    while ($row = $result->fetch_assoc()) {
        $bookings[] = $row;
    }
    respond($bookings);
}

// Cancel booking
if (preg_match('/^bookings\/(\d+)\/cancel$/', $route, $matches) && $method === 'POST') {
    $bookingId = (int)$matches[1];
    
    // Check if booking exists and get showtime info
    $result = $conn->query("
        SELECT b.*, s.ShowDate, s.ShowTime
        FROM bookings b
        JOIN showtimes s ON b.ShowtimeID = s.ShowtimeID
        WHERE b.BookingID = $bookingId
    ");
    if (!$result || $result->num_rows === 0) {
        respond(['error' => 'Vé không tồn tại'], 404);
    }
    
    $booking = $result->fetch_assoc();
    
    // Cannot cancel if already cancelled
    if ($booking['Status'] === 'CANCELLED') {
        respond(['error' => 'Vé này đã được hủy trước đó'], 400);
    }
    
    // Check time: only allow cancel if >= 30 minutes before showtime
    $showDateTime = strtotime($booking['ShowDate'] . ' ' . $booking['ShowTime']);
    $nowVN = time(); // PHP timezone đã set Asia/Ho_Chi_Minh ở đầu file
    $diffMinutes = ($showDateTime - $nowVN) / 60;
    
    if ($diffMinutes < 30) {
        respond(['error' => 'Chỉ được hủy vé trước 30 phút so với giờ chiếu'], 400);
    }
    
    // Update booking status
    $updateResult = $conn->query("UPDATE bookings SET Status = 'CANCELLED' WHERE BookingID = $bookingId");
    if (!$updateResult) {
        respond(['error' => 'Lỗi cập nhật: ' . $conn->error], 500);
    }
    
    // Update tickets status
    $conn->query("UPDATE tickets SET Status = 'CANCELLED' WHERE BookingID = $bookingId");
    
    respond(['success' => true, 'message' => 'Vé đã được hủy thành công']);
}

// ============================================
// PROMOTIONS API
// ============================================
if ($route === 'promotions' && $method === 'GET') {
    $result = $conn->query("
        SELECT PromotionID, Title, Code, Description, Discount, Type, 
               DATE_FORMAT(ExpiryDate, '%Y-%m-%d') AS ExpiryDate, 
               IsActive, DisplayText
        FROM promotions
        WHERE IsActive = 1 AND (ExpiryDate IS NULL OR ExpiryDate >= CURDATE())
        ORDER BY CreatedAt DESC
    ");
    
    if (!$result) {
        respond(['error' => 'Promotions query failed: ' . $conn->error], 500);
    }
    
    $promotions = [];
    while ($row = $result->fetch_assoc()) {
        $promotions[] = $row;
    }
    respond($promotions);
}

// Admin get all promotions (including inactive / expired)
if ($route === 'admin/promotions' && $method === 'GET') {
    $result = $conn->query("
        SELECT PromotionID, Title, Code, Description, Discount, Type, 
               DATE_FORMAT(ExpiryDate, '%Y-%m-%d') AS ExpiryDate, 
               IsActive, DisplayText
        FROM promotions
        ORDER BY CreatedAt DESC
    ");
    
    if (!$result) {
        respond(['error' => 'Admin promotions query failed: ' . $conn->error], 500);
    }
    
    $promotions = [];
    while ($row = $result->fetch_assoc()) {
        $promotions[] = $row;
    }
    respond($promotions);
}

// Admin create promotion
if ($route === 'admin/promotions' && $method === 'POST') {
    $data = get_json_body();
    $title = $conn->real_escape_string($data['Title'] ?? $data['title'] ?? '');
    $code = strtoupper(trim($conn->real_escape_string($data['Code'] ?? $data['code'] ?? '')));
    $description = $conn->real_escape_string($data['Description'] ?? $data['description'] ?? '');
    $discount = (int)($data['Discount'] ?? $data['discount'] ?? 0);
    $type = $conn->real_escape_string($data['Type'] ?? $data['type'] ?? 'percentage');
    $expiryDate = !empty($data['ExpiryDate'] ?? $data['expiryDate']) ? "'" . $conn->real_escape_string($data['ExpiryDate'] ?? $data['expiryDate']) . "'" : "NULL";
    $isActive = isset($data['IsActive']) ? (int)$data['IsActive'] : 1;
    $displayText = $conn->real_escape_string($data['DisplayText'] ?? $data['displayText'] ?? ($type === 'percentage' ? "$discount% OFF" : "Giảm " . number_format($discount) . "đ"));

    if (empty($code) || empty($title)) {
        respond(['error' => 'Vui lòng nhập đầy đủ mã và tiêu đề'], 400);
    }

    $insertQuery = "
        INSERT INTO promotions (Title, Code, Description, Discount, Type, ExpiryDate, IsActive, DisplayText)
        VALUES ('$title', '$code', '$description', $discount, '$type', $expiryDate, $isActive, '$displayText')
    ";

    if ($conn->query($insertQuery)) {
        $promoId = $conn->insert_id;
        $result = $conn->query("SELECT PromotionID, Title, Code, Description, Discount, Type, DATE_FORMAT(ExpiryDate, '%Y-%m-%d') AS ExpiryDate, IsActive, DisplayText FROM promotions WHERE PromotionID = $promoId");
        $saved = $result ? $result->fetch_assoc() : null;
        respond($saved, 201);
    } else {
        respond(['error' => 'Lỗi tạo khuyến mãi: ' . $conn->error], 500);
    }
}

// Admin update promotion
if (preg_match('/^admin\/promotions\/(\d+)$/', $route, $matches) && $method === 'PUT') {
    $promoId = (int)$matches[1];
    $data = get_json_body();
    $title = $conn->real_escape_string($data['Title'] ?? $data['title'] ?? '');
    $code = strtoupper(trim($conn->real_escape_string($data['Code'] ?? $data['code'] ?? '')));
    $description = $conn->real_escape_string($data['Description'] ?? $data['description'] ?? '');
    $discount = (int)($data['Discount'] ?? $data['discount'] ?? 0);
    $type = $conn->real_escape_string($data['Type'] ?? $data['type'] ?? 'percentage');
    $expiryDate = !empty($data['ExpiryDate'] ?? $data['expiryDate']) ? "'" . $conn->real_escape_string($data['ExpiryDate'] ?? $data['expiryDate']) . "'" : "NULL";
    $isActive = isset($data['IsActive']) ? (int)$data['IsActive'] : 1;
    $displayText = $conn->real_escape_string($data['DisplayText'] ?? $data['displayText'] ?? ($type === 'percentage' ? "$discount% OFF" : "Giảm " . number_format($discount) . "đ"));

    $updateQuery = "
        UPDATE promotions 
        SET Title = '$title', Code = '$code', Description = '$description', Discount = $discount,
            Type = '$type', ExpiryDate = $expiryDate, IsActive = $isActive, DisplayText = '$displayText'
        WHERE PromotionID = $promoId
    ";

    if ($conn->query($updateQuery)) {
        $result = $conn->query("SELECT PromotionID, Title, Code, Description, Discount, Type, DATE_FORMAT(ExpiryDate, '%Y-%m-%d') AS ExpiryDate, IsActive, DisplayText FROM promotions WHERE PromotionID = $promoId");
        $saved = $result ? $result->fetch_assoc() : null;
        respond($saved);
    } else {
        respond(['error' => 'Lỗi cập nhật khuyến mãi: ' . $conn->error], 500);
    }
}

// Admin delete promotion
if (preg_match('/^admin\/promotions\/(\d+)$/', $route, $matches) && $method === 'DELETE') {
    $promoId = (int)$matches[1];
    if ($conn->query("DELETE FROM promotions WHERE PromotionID = $promoId")) {
        respond(['success' => true, 'message' => 'Đã xoá khuyến mãi']);
    } else {
        respond(['error' => 'Lỗi xoá khuyến mãi: ' . $conn->error], 500);
    }
}

// ============================================
// AUTH API
// ============================================
if ($route === 'auth/login' && $method === 'POST') {
    $data = get_json_body();
    $email = $conn->real_escape_string($data['email']);
    $password = $conn->real_escape_string($data['password']);
    
    $result = $conn->query("SELECT UserID, FullName, Email, Phone, RoleID FROM users WHERE Email = '$email' AND Password = '$password'");
    
    if (!$result) {
        respond(['error' => 'Query failed: ' . $conn->error], 500);
    }
    
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        respond(['success' => true, 'user' => $user]);
    } else {
        respond(['success' => false, 'message' => 'Email hoặc mật khẩu không đúng'], 401);
    }
}

if ($route === 'auth/register' && $method === 'POST') {
    $data = get_json_body();
    $stmt = $conn->prepare("INSERT INTO users (FullName, Email, Password, Phone, RoleID) VALUES (?, ?, ?, ?, 1)");
    $stmt->bind_param('ssss', $data['fullName'], $data['email'], $data['password'], $data['phone']);
    
    if ($stmt->execute()) {
        $userId = $conn->insert_id;
        $result = $conn->query("SELECT UserID, FullName, Email, Phone FROM users WHERE UserID = $userId");
        if ($result) {
            $user = $result->fetch_assoc();
            respond(['success' => true, 'user' => $user], 201);
        }
    } else {
        respond(['error' => 'Lỗi đăng ký: ' . $stmt->error], 500);
    }
}

// ============================================
// TICKETS API
// ============================================
if (preg_match('/^tickets\/(.+?)$/', $route, $matches) && $method === 'GET') {
    $ticketCode = $conn->real_escape_string($matches[1]);
    
    $result = $conn->query("
        SELECT t.TicketID, t.TicketCode, t.SeatNumber, t.Status,
               b.BookingID, b.BookingCode, b.Status AS BookingStatus,
               u.FullName, u.Email, m.Title AS MovieTitle, m.PosterUrl,
               s.ShowDate, s.ShowTime, r.RoomName, c.Name AS CinemaName
        FROM tickets t
        JOIN bookings b ON t.BookingID = b.BookingID
        JOIN users u ON b.UserID = u.UserID
        JOIN showtimes s ON b.ShowtimeID = s.ShowtimeID
        JOIN movies m ON s.MovieID = m.MovieID
        JOIN rooms r ON s.RoomID = r.RoomID
        JOIN cinemas c ON r.CinemaID = c.CinemaID
        WHERE t.TicketCode = '$ticketCode'
    ");
    
    if (!$result) {
        respond(['error' => 'Query failed: ' . $conn->error], 500);
    }
    
    if ($result->num_rows === 0) {
        respond(['error' => 'Vé không tồn tại'], 404);
    }
    
    $ticket = $result->fetch_assoc();
    respond($ticket);
}

// ============================================
// STATS API
// ============================================
if ($route === 'stats/revenue' && $method === 'GET') {
    $result = $conn->query("
        SELECT DATE(b.CreatedAt) AS Date, SUM(b.TotalPrice) AS Revenue, COUNT(b.BookingID) AS TicketCount
        FROM bookings b
        WHERE b.Status = 'CONFIRMED'
        GROUP BY DATE(b.CreatedAt)
        ORDER BY Date DESC
    ");
    
    if (!$result) {
        respond(['error' => 'Query failed: ' . $conn->error], 500);
    }
    
    $stats = [];
    while ($row = $result->fetch_assoc()) {
        $stats[] = $row;
    }
    respond($stats);
}

if ($route === 'stats/revenue-by-movie' && $method === 'GET') {
    $result = $conn->query("
        SELECT m.Title, SUM(b.TotalPrice) AS Revenue, COUNT(b.BookingID) AS TicketCount
        FROM bookings b
        JOIN showtimes s ON b.ShowtimeID = s.ShowtimeID
        JOIN movies m ON s.MovieID = m.MovieID
        WHERE b.Status = 'CONFIRMED'
        GROUP BY m.MovieID, m.Title
        ORDER BY Revenue DESC
    ");
    
    if (!$result) {
        respond(['error' => 'Query failed: ' . $conn->error], 500);
    }
    
    $stats = [];
    while ($row = $result->fetch_assoc()) {
        $stats[] = $row;
    }
    respond($stats);
}

// Stats by cinema  
if ($route === 'stats/revenue-by-cinema' && $method === 'GET') {
    $result = $conn->query("
        SELECT c.CinemaID, c.Name AS CinemaName, SUM(b.TotalPrice) AS Revenue, COUNT(b.BookingID) AS TicketCount
        FROM bookings b
        JOIN showtimes s ON b.ShowtimeID = s.ShowtimeID
        JOIN rooms r ON s.RoomID = r.RoomID
        JOIN cinemas c ON r.CinemaID = c.CinemaID
        WHERE b.Status = 'CONFIRMED'
        GROUP BY c.CinemaID
        ORDER BY Revenue DESC
    ");
    
    if (!$result) {
        respond(['error' => 'Query failed: ' . $conn->error], 500);
    }
    
    $stats = [];
    while ($row = $result->fetch_assoc()) {
        $stats[] = $row;
    }
    respond($stats);
}

// Stats by cinema today
if ($route === 'stats/revenue-by-cinema-today' && $method === 'GET') {
    $result = $conn->query("
        SELECT c.CinemaID, c.Name AS CinemaName, SUM(b.TotalPrice) AS Revenue, COUNT(b.BookingID) AS TicketCount
        FROM bookings b
        JOIN showtimes s ON b.ShowtimeID = s.ShowtimeID
        JOIN rooms r ON s.RoomID = r.RoomID
        JOIN cinemas c ON r.CinemaID = c.CinemaID
        WHERE b.Status = 'CONFIRMED' AND DATE(b.CreatedAt) = CURDATE()
        GROUP BY c.CinemaID
        ORDER BY Revenue DESC
    ");
    
    if (!$result) {
        respond(['error' => 'Query failed: ' . $conn->error], 500);
    }
    
    $stats = [];
    while ($row = $result->fetch_assoc()) {
        $stats[] = $row;
    }
    respond($stats);
}

// Stats by cinema 7 days
if ($route === 'stats/revenue-by-cinema-7days' && $method === 'GET') {
    $result = $conn->query("
        SELECT c.CinemaID, c.Name AS CinemaName, SUM(b.TotalPrice) AS Revenue, COUNT(b.BookingID) AS TicketCount
        FROM bookings b
        JOIN showtimes s ON b.ShowtimeID = s.ShowtimeID
        JOIN rooms r ON s.RoomID = r.RoomID
        JOIN cinemas c ON r.CinemaID = c.CinemaID
        WHERE b.Status = 'CONFIRMED' AND b.CreatedAt >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
        GROUP BY c.CinemaID
        ORDER BY Revenue DESC
    ");
    
    if (!$result) {
        respond(['error' => 'Query failed: ' . $conn->error], 500);
    }
    
    $stats = [];
    while ($row = $result->fetch_assoc()) {
        $stats[] = $row;
    }
    respond($stats);
}

// Stats by cinema 30 days
if ($route === 'stats/revenue-by-cinema-30days' && $method === 'GET') {
    $result = $conn->query("
        SELECT c.CinemaID, c.Name AS CinemaName, SUM(b.TotalPrice) AS Revenue, COUNT(b.BookingID) AS TicketCount
        FROM bookings b
        JOIN showtimes s ON b.ShowtimeID = s.ShowtimeID
        JOIN rooms r ON s.RoomID = r.RoomID
        JOIN cinemas c ON r.CinemaID = c.CinemaID
        WHERE b.Status = 'CONFIRMED' AND b.CreatedAt >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
        GROUP BY c.CinemaID
        ORDER BY Revenue DESC
    ");
    
    if (!$result) {
        respond(['error' => 'Query failed: ' . $conn->error], 500);
    }
    
    $stats = [];
    while ($row = $result->fetch_assoc()) {
        $stats[] = $row;
    }
    respond($stats);
}

// 404 - Route not found
respond(['error' => 'Route không tồn tại: ' . $route, 'method' => $method], 404);
?>