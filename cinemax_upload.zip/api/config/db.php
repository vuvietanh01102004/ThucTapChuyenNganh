<?php
declare(strict_types=1);

$DB_HOST = 'sql205.infinityfree.com';
$DB_NAME = 'if0_42676221_cinemax';
$DB_USER = 'if0_42676221';
$DB_PASS = 'Pdl0nzhHG2QyR';
$DB_PORT = 3306;

try {
  // Use MySQLi instead of PDO for better compatibility
  $conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME, $DB_PORT);
  
  // Check connection
  if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode([
      'error' => 'Database connection failed',
      'details' => $conn->connect_error,
      'host' => $DB_HOST,
      'port' => $DB_PORT,
      'db' => $DB_NAME
    ]);
    exit;
  }
  
  // Set charset
  $conn->set_charset("utf8mb4");
  
} catch (Exception $e) {
  http_response_code(500);
  echo json_encode([
    'error' => 'PHP Exception',
    'message' => $e->getMessage()
  ]);
  exit;
}

return $conn;