<?php
/**
 * Script to execute SQL file and update showtimes
 * This file loads showtimes-current.sql and executes it on the database
 */

// Database connection
$DB_HOST = 'sql205.infinityfree.com';
$DB_NAME = 'if0_42676221_cinemax';
$DB_USER = 'if0_42676221';
$DB_PASS = 'Pdl0nzhHG2QyR';
$DB_PORT = 3306;

try {
    $conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME, $DB_PORT);
    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    $conn->set_charset("utf8mb4");
    echo "✓ Connected to database successfully\n";
    
    // Read the SQL file
    $sqlFile = __DIR__ . '/../showtimes-current.sql';
    
    if (!file_exists($sqlFile)) {
        die("❌ File not found: $sqlFile\n");
    }
    
    $sql = file_get_contents($sqlFile);
    echo "✓ SQL file loaded\n";
    
    // Execute the SQL file
    if ($conn->multi_query($sql)) {
        echo "✓ Executing SQL queries...\n";
        
        $queryCount = 0;
        do {
            if ($result = $conn->store_result()) {
                $result->free();
            }
            $queryCount++;
        } while ($conn->next_result());
        
        echo "✓ All queries executed successfully ($queryCount queries)\n";
        
        // Verify data was inserted
        $verifyResult = $conn->query("SELECT COUNT(*) as total FROM showtimes");
        if ($verifyResult) {
            $row = $verifyResult->fetch_assoc();
            echo "✓ Total showtimes in database: " . $row['total'] . "\n";
        }
        
    } else {
        echo "❌ Error executing SQL: " . $conn->error . "\n";
    }
    
    $conn->close();
    echo "\n✓ Script completed!\n";
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
}
?>
